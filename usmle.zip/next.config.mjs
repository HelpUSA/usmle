/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep it simple. No turbopack flags here.
};

export default nextConfig;
