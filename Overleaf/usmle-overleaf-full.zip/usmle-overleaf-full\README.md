﻿# USMLE API Handbook (Overleaf project)

## How to compile on Overleaf
- Upload this project as a ZIP to Overleaf.
- Set the main file to `main.tex`.
- Compiler: pdfLaTeX is fine.
- Bibliography tool: **Biber** (required by BibLaTeX).

## Notes
This is intended to be a living document updated frequently as development progresses.
