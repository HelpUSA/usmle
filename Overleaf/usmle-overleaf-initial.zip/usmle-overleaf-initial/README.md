# USMLE API Handbook (Overleaf project)

Upload this ZIP to Overleaf and set `main.tex` as the main file.
Use Biber for bibliography.
